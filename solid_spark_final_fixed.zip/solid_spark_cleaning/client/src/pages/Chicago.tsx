import { MapPin, Phone, Mail, ArrowRight, Star } from "lucide-react";
import { Link } from "wouter";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

export default function Chicago() {
  const neighborhoods = [
    "Downtown Chicago",
    "Lincoln Park",
    "Wicker Park",
    "Pilsen",
    "Hyde Park",
    "Lakeview",
    "River North",
    "West Loop",
  ];

  const reviews = [
    {
      name: "Марія Петренко",
      rating: 5,
      text: "Чудова команда! Дуже професійні та пунктуальні. Мій офіс виглядає як новий!",
      area: "Downtown Chicago",
    },
    {
      name: "Іван Коваленко",
      rating: 5,
      text: "Найкращий сервіс прибирання в Чикаго. Рекомендую всім своїм друзям.",
      area: "Lincoln Park",
    },
    {
      name: "Анна Сидоренко",
      rating: 5,
      text: "Швидко, якісно, недорого. Саме те, що мені було потрібно!",
      area: "Wicker Park",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-accent/10 to-accent/5 border-b border-border">
        <div className="container">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 mb-4">
              <MapPin size={20} className="text-accent" />
              <span className="text-accent font-mono text-sm font-semibold">ЧИКАГО, IL</span>
            </div>
            <h1 className="font-display text-5xl md:text-6xl font-bold text-foreground mb-4">
              Послуги прибирання у Чикаго
            </h1>
            <p className="text-xl text-foreground/60">
              Професійні послуги прибирання для жилих та комерційних приміщень у Чикаго та його передмістях.
            </p>
          </div>
        </div>
      </section>

      {/* Service Areas */}
      <section className="py-20 md:py-32">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              Обслуговувані райони Чикаго
            </h2>
            <p className="text-xl text-foreground/60">
              Ми обслуговуємо всі основні райони міста
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            {neighborhoods.map((neighborhood, i) => (
              <div
                key={i}
                className="bg-card border border-border rounded-lg p-4 text-center hover:border-accent/50 smooth-transition"
              >
                <p className="font-semibold text-foreground">{neighborhood}</p>
              </div>
            ))}
          </div>

          <div className="bg-gradient-to-r from-accent/10 to-accent/5 rounded-xl p-8 md:p-12 text-center">
            <h3 className="font-display text-2xl font-bold text-foreground mb-4">
              Ваш район не в списку?
            </h3>
            <p className="text-foreground/60 mb-6">
              Зв'яжіться з нами для уточнення можливості обслуговування вашої адреси
            </p>
            <a
              href="https://wa.me/1234567890"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-accent text-accent-foreground px-8 py-3 rounded-lg hover:shadow-lg smooth-transition button-press font-semibold"
            >
              Запитати
              <ArrowRight size={18} />
            </a>
          </div>
        </div>
      </section>

      {/* Why Chicago */}
      <section className="py-20 md:py-32 bg-secondary/30 border-y border-border">
        <div className="container">
          <div className="max-w-3xl">
            <h2 className="font-display text-4xl font-bold text-foreground mb-6">
              Послуги для Чикаго
            </h2>
            <div className="space-y-4 text-foreground/70">
              <p>
                Solid Spark спеціалізується на прибиранні для жителів та бізнесів Чикаго. Ми розуміємо унікальні потреби міста та його різноманітних районів.
              </p>
              <p>
                Від скромних квартир у Lincoln Park до великих офісів у Downtown Chicago, наша команда готова до будь-якого завдання.
              </p>
              <p>
                Ми використовуємо екологічні засоби та сучасне обладнання для забезпечення найвищої якості прибирання.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="py-20 md:py-32">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              Відгуки від чикаганців
            </h2>
            <p className="text-xl text-foreground/60">
              Що кажуть наші клієнти з Чикаго
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {reviews.map((review, i) => (
              <div key={i} className="bg-card border border-border rounded-xl p-8">
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(review.rating)].map((_, j) => (
                    <Star key={j} size={18} className="fill-accent text-accent" />
                  ))}
                </div>
                <p className="text-foreground/70 mb-4 italic">"{review.text}"</p>
                <div className="pt-4 border-t border-border">
                  <p className="font-semibold text-foreground">{review.name}</p>
                  <p className="text-sm text-foreground/60">{review.area}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 md:py-32 bg-gradient-to-r from-accent/10 to-accent/5 border-y border-border">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-6">
              Зв'яжіться з нами
            </h2>
            <p className="text-xl text-foreground/60 mb-8">
              Готові замовити послуги прибирання у Чикаго?
            </p>

            <div className="space-y-4">
              <a
                href="https://wa.me/1234567890"
                target="_blank"
                rel="noopener noreferrer"
                className="block bg-accent text-accent-foreground px-8 py-4 rounded-lg hover:shadow-xl smooth-transition button-press font-semibold"
              >
                WhatsApp
              </a>
              <a
                href="tel:+1234567890"
                className="block border-2 border-accent text-accent px-8 py-4 rounded-lg hover:bg-accent/10 smooth-transition button-press font-semibold flex items-center justify-center gap-2"
              >
                <Phone size={20} />
                +1 (234) 567-890
              </a>
              <a
                href="mailto:chicago@solidsparkclean.com"
                className="block border-2 border-accent text-accent px-8 py-4 rounded-lg hover:bg-accent/10 smooth-transition button-press font-semibold flex items-center justify-center gap-2"
              >
                <Mail size={20} />
                chicago@solidsparkclean.com
              </a>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
