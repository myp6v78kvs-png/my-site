import { MapPin, Phone, Mail, ArrowRight, Star } from "lucide-react";
import { Link } from "wouter";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

export default function Ohio() {
  const cities = [
    "Columbus",
    "Cleveland",
    "Cincinnati",
    "Toledo",
    "Akron",
    "Dayton",
    "Parma",
    "Canton",
  ];

  const reviews = [
    {
      name: "Джон Сміт",
      rating: 5,
      text: "Відмінна робота! Мій будинок у Columbus виглядає бездоганно. Дуже рекомендую!",
      area: "Columbus, OH",
    },
    {
      name: "Сара Джонсон",
      rating: 5,
      text: "Найкращий сервіс прибирання, який я коли-небудь використовував. Вартість справедлива!",
      area: "Cleveland, OH",
    },
    {
      name: "Майк Браун",
      rating: 5,
      text: "Професіонали своєї справи. Мій офіс у Cincinnati завжди чистий та свіжий.",
      area: "Cincinnati, OH",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-accent/10 to-accent/5 border-b border-border">
        <div className="container">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 mb-4">
              <MapPin size={20} className="text-accent" />
              <span className="text-accent font-mono text-sm font-semibold">ОГАЙО, OH</span>
            </div>
            <h1 className="font-display text-5xl md:text-6xl font-bold text-foreground mb-4">
              Послуги прибирання в Огайо
            </h1>
            <p className="text-xl text-foreground/60">
              Професійні послуги прибирання для жилих та комерційних приміщень по всьому штату Огайо.
            </p>
          </div>
        </div>
      </section>

      {/* Service Areas */}
      <section className="py-20 md:py-32">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              Обслуговувані міста Огайо
            </h2>
            <p className="text-xl text-foreground/60">
              Ми обслуговуємо основні міста штату
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            {cities.map((city, i) => (
              <div
                key={i}
                className="bg-card border border-border rounded-lg p-4 text-center hover:border-accent/50 smooth-transition"
              >
                <p className="font-semibold text-foreground">{city}</p>
              </div>
            ))}
          </div>

          <div className="bg-gradient-to-r from-accent/10 to-accent/5 rounded-xl p-8 md:p-12 text-center">
            <h3 className="font-display text-2xl font-bold text-foreground mb-4">
              Ваше місто не в списку?
            </h3>
            <p className="text-foreground/60 mb-6">
              Зв'яжіться з нами для уточнення можливості обслуговування вашої адреси
            </p>
            <a
              href="https://wa.me/1234567890"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-accent text-accent-foreground px-8 py-3 rounded-lg hover:shadow-lg smooth-transition button-press font-semibold"
            >
              Запитати
              <ArrowRight size={18} />
            </a>
          </div>
        </div>
      </section>

      {/* Why Ohio */}
      <section className="py-20 md:py-32 bg-secondary/30 border-y border-border">
        <div className="container">
          <div className="max-w-3xl">
            <h2 className="font-display text-4xl font-bold text-foreground mb-6">
              Послуги для Огайо
            </h2>
            <div className="space-y-4 text-foreground/70">
              <p>
                Solid Spark пропонує професійні послуги прибирання для всіх основних міст Огайо. Від Columbus до Cleveland, ми готові обслужити вас.
              </p>
              <p>
                Наша команда має досвід роботи з різними типами приміщень - від приватних будинків до великих комерційних об'єктів.
              </p>
              <p>
                Ми гордимося якістю нашої роботи та задоволенням наших клієнтів по всьому штату.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="py-20 md:py-32">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              Відгуки від жителів Огайо
            </h2>
            <p className="text-xl text-foreground/60">
              Що кажуть наші клієнти з Огайо
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {reviews.map((review, i) => (
              <div key={i} className="bg-card border border-border rounded-xl p-8">
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(review.rating)].map((_, j) => (
                    <Star key={j} size={18} className="fill-accent text-accent" />
                  ))}
                </div>
                <p className="text-foreground/70 mb-4 italic">"{review.text}"</p>
                <div className="pt-4 border-t border-border">
                  <p className="font-semibold text-foreground">{review.name}</p>
                  <p className="text-sm text-foreground/60">{review.area}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 md:py-32 bg-gradient-to-r from-accent/10 to-accent/5 border-y border-border">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-6">
              Зв'яжіться з нами
            </h2>
            <p className="text-xl text-foreground/60 mb-8">
              Готові замовити послуги прибирання в Огайо?
            </p>

            <div className="space-y-4">
              <a
                href="https://wa.me/1234567890"
                target="_blank"
                rel="noopener noreferrer"
                className="block bg-accent text-accent-foreground px-8 py-4 rounded-lg hover:shadow-xl smooth-transition button-press font-semibold"
              >
                WhatsApp
              </a>
              <a
                href="tel:+1234567890"
                className="block border-2 border-accent text-accent px-8 py-4 rounded-lg hover:bg-accent/10 smooth-transition button-press font-semibold flex items-center justify-center gap-2"
              >
                <Phone size={20} />
                +1 (234) 567-890
              </a>
              <a
                href="mailto:ohio@solidsparkclean.com"
                className="block border-2 border-accent text-accent px-8 py-4 rounded-lg hover:bg-accent/10 smooth-transition button-press font-semibold flex items-center justify-center gap-2"
              >
                <Mail size={20} />
                ohio@solidsparkclean.com
              </a>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
