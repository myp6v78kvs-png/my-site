import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

export default function Gallery() {
  const galleryItems = [
    { title: "Office Deep Clean", before: "🏢", after: "✨" },
    { title: "Residential Cleaning", before: "🏠", after: "🌟" },
    { title: "Carpet Cleaning", before: "🧹", after: "✨" },
    { title: "Window Cleaning", before: "🪟", after: "💎" },
    { title: "Kitchen Deep Clean", before: "🍳", after: "✨" },
    { title: "Bathroom Cleaning", before: "🚿", after: "🌟" },
    { title: "Living Room", before: "🛋️", after: "✨" },
    { title: "Bedroom Refresh", before: "🛏️", after: "🌟" },
    { title: "Hallway Clean", before: "🚪", after: "✨" },
    { title: "Basement Deep Clean", before: "📦", after: "🌟" },
    { title: "Garage Organization", before: "🚗", after: "✨" },
    { title: "Staircase Cleaning", before: "🪜", after: "🌟" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-accent/10 to-accent/5 border-b border-border">
        <div className="container">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 mb-4">
              <div className="accent-line"></div>
              <span className="text-accent font-mono text-sm font-semibold">GALLERY</span>
            </div>
            <h1 className="font-display text-5xl md:text-6xl font-bold text-foreground mb-4">
              Before & After
            </h1>
            <p className="text-xl text-foreground/60">
              See the transformation our professional cleaning brings to homes and offices
            </p>
          </div>
        </div>
      </section>

      {/* Gallery Grid */}
      <section className="py-20 md:py-32">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {galleryItems.map((item, i) => (
              <div
                key={i}
                className="bg-card border border-border rounded-xl overflow-hidden hover:shadow-lg smooth-transition"
              >
                <div className="grid grid-cols-2 gap-4 p-6">
                  {/* Before */}
                  <div className="space-y-2">
                    <div className="bg-secondary/30 rounded-lg h-40 flex items-center justify-center border-2 border-dashed border-foreground/20 hover:border-foreground/40 transition-colors">
                      <div className="text-center space-y-2">
                        <span className="text-4xl block">{item.before}</span>
                        <p className="text-xs text-foreground/40">Add before photo</p>
                      </div>
                    </div>
                    <p className="text-xs font-semibold text-foreground/60 text-center">BEFORE</p>
                  </div>

                  {/* After */}
                  <div className="space-y-2">
                    <div className="bg-accent/10 rounded-lg h-40 flex items-center justify-center border-2 border-dashed border-accent/20 hover:border-accent/40 transition-colors">
                      <div className="text-center space-y-2">
                        <span className="text-4xl block">{item.after}</span>
                        <p className="text-xs text-accent/40">Add after photo</p>
                      </div>
                    </div>
                    <p className="text-xs font-semibold text-accent text-center">AFTER</p>
                  </div>
                </div>

                <div className="px-6 pb-6 border-t border-border">
                  <h3 className="font-display text-lg font-bold text-foreground">
                    {item.title}
                  </h3>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32 bg-gradient-to-r from-accent/10 to-accent/5 border-y border-border">
        <div className="container text-center">
          <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-6">
            Ready for Your Transformation?
          </h2>
          <p className="text-xl text-foreground/60 mb-8 max-w-2xl mx-auto">
            Let us transform your space into something beautiful
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://wa.me/6143648613"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-accent text-accent-foreground px-8 py-4 rounded-lg hover:shadow-xl smooth-transition button-press font-semibold"
            >
              WhatsApp
            </a>
            <a
              href="mailto:solidspark45@gmail.com"
              className="border-2 border-accent text-accent px-8 py-4 rounded-lg hover:bg-accent/10 smooth-transition button-press font-semibold"
            >
              Email
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
