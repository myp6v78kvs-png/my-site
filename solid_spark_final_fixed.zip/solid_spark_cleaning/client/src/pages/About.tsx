import { Star, Users, Award, Heart } from "lucide-react";
import { Link } from "wouter";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

export default function About() {
  const reviews = [
    {
      name: "Марія Петренко",
      rating: 5,
      text: "Чудова команда! Дуже професійні та пунктуальні. Мій офіс виглядає як новий!",
      area: "Downtown Chicago",
      date: "2 місяці тому",
    },
    {
      name: "Іван Коваленко",
      rating: 5,
      text: "Найкращий сервіс прибирання в Чикаго. Рекомендую всім своїм друзям.",
      area: "Lincoln Park",
      date: "1 місяць тому",
    },
    {
      name: "Анна Сидоренко",
      rating: 5,
      text: "Швидко, якісно, недорого. Саме те, що мені було потрібно!",
      area: "Wicker Park",
      date: "3 тижні тому",
    },
    {
      name: "Джон Сміт",
      rating: 5,
      text: "Відмінна робота! Мій будинок у Columbus виглядає бездоганно. Дуже рекомендую!",
      area: "Columbus, OH",
      date: "2 тижні тому",
    },
    {
      name: "Сара Джонсон",
      rating: 5,
      text: "Найкращий сервіс прибирання, який я коли-небудь використовував. Вартість справедлива!",
      area: "Cleveland, OH",
      date: "1 тиждень тому",
    },
    {
      name: "Майк Браун",
      rating: 5,
      text: "Професіонали своєї справи. Мій офіс у Cincinnati завжди чистий та свіжий.",
      area: "Cincinnati, OH",
      date: "5 днів тому",
    },
    {
      name: "Олена Василенко",
      rating: 5,
      text: "Дуже задоволена результатом! Команда була ввічлива та акуратна. Замовлю ще!",
      area: "Lakeview, Chicago",
      date: "4 дні тому",
    },
    {
      name: "Павло Мельник",
      rating: 5,
      text: "Прибирання на найвищому рівні. Ціна справедлива. Рекомендую!",
      area: "River North",
      date: "3 дні тому",
    },
    {
      name: "Катерина Гордієнко",
      rating: 5,
      text: "Чудові хлопці! Все зробили швидко та якісно. Дякую!",
      area: "West Loop",
      date: "2 дні тому",
    },
    {
      name: "Андрій Шевченко",
      rating: 5,
      text: "Найкращий вибір для прибирання. Команда дуже професійна!",
      area: "Pilsen",
      date: "2 дні тому",
    },
    {
      name: "Наталія Бондаренко",
      rating: 5,
      text: "Дякую за відмінну роботу! Все чисто та акуратно. Буду замовляти регулярно!",
      area: "Hyde Park",
      date: "1 день тому",
    },
    {
      name: "Вадим Кравченко",
      rating: 5,
      text: "Професіонали! Мій офіс сяє чистотою. Дуже рекомендую!",
      area: "Toledo, OH",
      date: "1 день тому",
    },
    {
      name: "Ірина Романенко",
      rating: 5,
      text: "Чудова команда! Швидко, якісно, надійно. Спасибі!",
      area: "Akron, OH",
      date: "1 день тому",
    },
    {
      name: "Сергій Литвин",
      rating: 5,
      text: "Найкращий сервіс! Мій дім виглядає як новий. Дякую!",
      area: "Dayton, OH",
      date: "1 день тому",
    },
    {
      name: "Ольга Коваль",
      rating: 5,
      text: "Дуже задоволена! Команда дуже ввічлива та професійна!",
      area: "Parma, OH",
      date: "1 день тому",
    },
    {
      name: "Максим Федоренко",
      rating: 5,
      text: "Чудова робота! Все на найвищому рівні. Рекомендую!",
      area: "Canton, OH",
      date: "1 день тому",
    },
    {
      name: "Юлія Петрова",
      rating: 5,
      text: "Найкращий вибір! Команда дуже професійна та ввічлива!",
      area: "Chicago, IL",
      date: "1 день тому",
    },
    {
      name: "Артем Морозов",
      rating: 5,
      text: "Дякую за відмінну роботу! Все чисто та акуратно!",
      area: "Columbus, OH",
      date: "1 день тому",
    },
    {
      name: "Вероніка Кравченко",
      rating: 5,
      text: "Чудові хлопці! Мій офіс виглядає як новий!",
      area: "Cleveland, OH",
      date: "1 день тому",
    },
    {
      name: "Денис Сидоренко",
      rating: 5,
      text: "Найкращий сервіс! Рекомендую всім!",
      area: "Cincinnati, OH",
      date: "1 день тому",
    },
    {
      name: "Ксенія Василевич",
      rating: 5,
      text: "Дуже задоволена результатом! Спасибі!",
      area: "Chicago, IL",
      date: "1 день тому",
    },
    {
      name: "Роман Гавриленко",
      rating: 5,
      text: "Чудова команда! Все на найвищому рівні!",
      area: "Chicago, IL",
      date: "1 день тому",
    },
    {
      name: "Софія Лисенко",
      rating: 5,
      text: "Найкращий вибір для прибирання!",
      area: "Ohio",
      date: "1 день тому",
    },
    {
      name: "Ігор Бойко",
      rating: 5,
      text: "Дякую за професійну роботу!",
      area: "Chicago, IL",
      date: "1 день тому",
    },
    {
      name: "Марина Козак",
      rating: 5,
      text: "Чудові результати! Рекомендую!",
      area: "Ohio",
      date: "1 день тому",
    },
    {
      name: "Віктор Герета",
      rating: 5,
      text: "Найкращий сервіс в місті!",
      area: "Chicago, IL",
      date: "1 день тому",
    },
    {
      name: "Галина Мазепа",
      rating: 5,
      text: "Дуже задоволена! Спасибі!",
      area: "Ohio",
      date: "1 день тому",
    },
    {
      name: "Станіслав Ковальчук",
      rating: 5,
      text: "Чудова робота! Дякую!",
      area: "Chicago, IL",
      date: "1 день тому",
    },
    {
      name: "Раїса Кравець",
      rating: 5,
      text: "Найкращий вибір!",
      area: "Ohio",
      date: "1 день тому",
    },
    {
      name: "Геннадій Шумило",
      rating: 5,
      text: "Дякую за все!",
      area: "Chicago, IL",
      date: "1 день тому",
    },
    {
      name: "Валентина Литвин",
      rating: 5,
      text: "Чудово!",
      area: "Ohio",
      date: "1 день тому",
    },
  ];

  const values = [
    {
      icon: Award,
      title: "Якість",
      description: "Ми гарантуємо найвищу якість прибирання на кожному проекті.",
    },
    {
      icon: Users,
      title: "Команда",
      description: "Наша досвідчена команда готова до будь-якого завдання.",
    },
    {
      icon: Heart,
      title: "Турбота",
      description: "Ми піклуємося про ваш простір так само, як про свій.",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-accent/10 to-accent/5 border-b border-border">
        <div className="container">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 mb-4">
              <div className="accent-line"></div>
              <span className="text-accent font-mono text-sm font-semibold">ПРО НАС</span>
            </div>
            <h1 className="font-display text-5xl md:text-6xl font-bold text-foreground mb-4">
              Solid Spark - Ваш партнер у чистоті
            </h1>
            <p className="text-xl text-foreground/60">
              Ми присвячуємо себе забезпеченню найвищої якості послуг прибирання для Чикаго та Огайо.
            </p>
          </div>
        </div>
      </section>

      {/* Company Story */}
      <section className="py-20 md:py-32">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="font-display text-4xl font-bold text-foreground mb-6">
                Наша історія
              </h2>
              <div className="space-y-4 text-foreground/70">
                <p>
                  Solid Spark була заснована з однією простою метою: надати професійні послуги прибирання, які перевищують очікування наших клієнтів.
                </p>
                <p>
                  З більш ніж 10 років досвіду, наша команда розвинула глибоке розуміння того, що потрібно для створення чистого, здорового простору.
                </p>
                <p>
                  Сьогодні ми гордимося тим, що обслуговуємо сотні задоволених клієнтів у Чикаго та Огайо.
                </p>
              </div>
            </div>
            <div className="bg-gradient-to-br from-accent/10 to-accent/5 rounded-2xl p-12 h-96 flex items-center justify-center">
              <div className="text-center">
                <div className="font-display text-6xl font-bold text-accent mb-4">10+</div>
                <p className="text-foreground/60 text-lg">Років досвіду</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 md:py-32 bg-secondary/30 border-y border-border">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              Наші цінності
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((value, i) => {
              const Icon = value.icon;
              return (
                <div key={i} className="bg-card border border-border rounded-xl p-8 text-center">
                  <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Icon size={32} className="text-accent" />
                  </div>
                  <h3 className="font-display text-2xl font-bold text-foreground mb-2">
                    {value.title}
                  </h3>
                  <p className="text-foreground/60">{value.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section className="py-20 md:py-32">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              Відгуки наших клієнтів
            </h2>
            <p className="text-xl text-foreground/60">
              Більше 30 задоволених клієнтів поділяються своїми враженнями
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {reviews.map((review, i) => (
              <div
                key={i}
                className="bg-card border border-border rounded-xl p-6 hover:shadow-lg smooth-transition"
              >
                <div className="flex items-center gap-1 mb-3">
                  {[...Array(review.rating)].map((_, j) => (
                    <Star key={j} size={16} className="fill-accent text-accent" />
                  ))}
                </div>
                <p className="text-foreground/70 mb-4 line-clamp-3 italic">
                  "{review.text}"
                </p>
                <div className="pt-4 border-t border-border">
                  <p className="font-semibold text-foreground text-sm">{review.name}</p>
                  <p className="text-xs text-foreground/60">{review.area}</p>
                  <p className="text-xs text-foreground/50 mt-1">{review.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="py-20 md:py-32 bg-gradient-to-r from-accent/10 to-accent/5 border-y border-border">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {[
              { number: "500+", label: "Задоволених клієнтів" },
              { number: "5000+", label: "Завершених проектів" },
              { number: "10+", label: "Років досвіду" },
              { number: "24/7", label: "Доступна підтримка" },
            ].map((stat, i) => (
              <div key={i} className="text-center">
                <div className="font-display text-4xl md:text-5xl font-bold text-accent mb-2">
                  {stat.number}
                </div>
                <p className="text-foreground/60 font-medium">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 md:py-32">
        <div className="container text-center">
          <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-6">
            Готові до чистоти?
          </h2>
          <p className="text-xl text-foreground/60 mb-8 max-w-2xl mx-auto">
            Зв'яжіться з нами сьогодні для безплатної консультації
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://wa.me/1234567890"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-accent text-accent-foreground px-8 py-4 rounded-lg hover:shadow-xl smooth-transition button-press font-semibold"
            >
              WhatsApp
            </a>
            <a
              href="mailto:info@solidsparkclean.com"
              className="border-2 border-accent text-accent px-8 py-4 rounded-lg hover:bg-accent/10 smooth-transition button-press font-semibold"
            >
              Email
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
