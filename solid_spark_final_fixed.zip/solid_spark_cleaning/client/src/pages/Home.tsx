import { Star, CheckCircle2, ArrowRight, Sparkles } from "lucide-react";
import { Link } from "wouter";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import BookingForm from "@/components/BookingForm";

export default function Home() {
  const services = [
    {
      title: "Residential Cleaning",
      description: "Comprehensive apartment and house cleaning with eco-friendly products.",
      icon: "🏠",
    },
    {
      title: "Office Cleaning",
      description: "Professional office space cleaning for cleanliness and productivity.",
      icon: "🏢",
    },
    {
      title: "Deep Cleaning",
      description: "Thorough cleaning of every corner of your space.",
      icon: "✨",
    },
    {
      title: "Carpet Cleaning",
      description: "Specialized carpet and furniture cleaning services.",
      icon: "🧹",
    },
    {
      title: "Pest Control",
      description: "Safe treatment for insects and pests.",
      icon: "🛡️",
    },
    {
      title: "Window Cleaning",
      description: "Professional window and glass cleaning.",
      icon: "🪟",
    },
  ];

  const stats = [
    { number: "500+", label: "Satisfied Clients" },
    { number: "5000+", label: "Completed Projects" },
    { number: "10+", label: "Years Experience" },
    { number: "24/7", label: "Support Available" },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="relative py-20 md:py-32 overflow-hidden">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            {/* Left Content */}
            <div className="space-y-8">
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <div className="accent-line"></div>
                  <span className="text-accent font-mono text-sm font-semibold">
                    SOLID SPARK CLEANING
                  </span>
                </div>
                <h1 className="font-display text-5xl md:text-6xl font-bold text-foreground leading-tight">
                  Sparkling Clean Spaces
                </h1>
                <p className="text-xl text-foreground/70 leading-relaxed">
                  Professional cleaning services across Chicago, Houston, Cleveland, Columbus, and Parma. We make your space clean, fresh, and healthy.
                </p>
              </div>

              {/* CTA Buttons */}
              <div className="flex flex-col sm:flex-row gap-4">
                <Link href="/services">
                  <a className="bg-accent text-accent-foreground px-8 py-4 rounded-lg hover:shadow-xl smooth-transition button-press font-semibold flex items-center justify-center gap-2">
                    View Services
                    <ArrowRight size={20} />
                  </a>
                </Link>
                <a
                  href="https://wa.me/6143648613"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="border-2 border-accent text-accent px-8 py-4 rounded-lg hover:bg-accent/10 smooth-transition button-press font-semibold flex items-center justify-center gap-2"
                >
                  <Sparkles size={20} />
                  Book Now
                </a>
              </div>

              {/* Trust Indicators */}
              <div className="flex items-center gap-6 pt-4">
                <div className="flex -space-x-2">
                  {[1, 2, 3].map((i) => (
                    <div
                      key={i}
                      className="w-10 h-10 rounded-full bg-accent/20 border-2 border-background flex items-center justify-center text-accent font-bold"
                    >
                      {i}
                    </div>
                  ))}
                </div>
                <div>
                  <div className="flex items-center gap-1 mb-1">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} size={16} className="fill-accent text-accent" />
                    ))}
                  </div>
                  <p className="text-sm text-foreground/60">
                    30+ reviews from satisfied clients
                  </p>
                </div>
              </div>
            </div>

            {/* Right - Hero Image Placeholder */}
            <div className="relative h-96 md:h-full hidden md:block rounded-3xl overflow-hidden bg-gradient-to-br from-accent/10 to-accent/5 border-2 border-accent/20 flex items-center justify-center">
              <div className="text-center space-y-4">
                <div className="text-6xl">📸</div>
                <p className="text-foreground/60 font-semibold">Add your hero image here</p>
                <p className="text-sm text-foreground/40">Replace with your best cleaning project photo</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-secondary/30 border-y border-border">
        <div className="container">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, i) => (
              <div key={i} className="text-center">
                <div className="font-display text-4xl md:text-5xl font-bold text-accent mb-2">
                  {stat.number}
                </div>
                <p className="text-foreground/60 font-medium">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 md:py-32">
        <div className="container">
          <div className="text-center mb-16">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="accent-line"></div>
              <span className="text-accent font-mono text-sm font-semibold">
                SERVICES
              </span>
              <div className="accent-line"></div>
            </div>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              What We Offer
            </h2>
            <p className="text-xl text-foreground/60 max-w-2xl mx-auto">
              Complete range of cleaning services for your home and office
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, i) => (
              <div
                key={i}
                className="group bg-card border border-border rounded-xl p-8 hover:shadow-lg smooth-transition hover:border-accent/50"
              >
                <div className="text-5xl mb-4">{service.icon}</div>
                <h3 className="font-display text-xl font-bold text-foreground mb-2">
                  {service.title}
                </h3>
                <p className="text-foreground/60 mb-4">{service.description}</p>
                <div className="flex items-center gap-2 text-accent font-semibold group-hover:gap-3 smooth-transition">
                  <CheckCircle2 size={18} />
                  <span>Learn More</span>
                </div>
              </div>
            ))}
          </div>

          <div className="text-center mt-12">
            <Link href="/services">
              <a className="inline-flex items-center gap-2 text-accent font-semibold hover:gap-3 smooth-transition">
                View All Services
                <ArrowRight size={20} />
              </a>
            </Link>
          </div>
        </div>
      </section>

      {/* Booking Section */}
      <section className="py-20 md:py-32 bg-secondary/30 border-y border-border">
        <div className="container">
          <div className="text-center mb-16">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="accent-line"></div>
              <span className="text-accent font-mono text-sm font-semibold">
                BOOK NOW
              </span>
              <div className="accent-line"></div>
            </div>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              Schedule Your Cleaning
            </h2>
            <p className="text-xl text-foreground/60 max-w-2xl mx-auto">
              Fill out the form below and we'll get back to you shortly
            </p>
          </div>
          <BookingForm />
        </div>
      </section>

      {/* Before & After Section */}
      <section className="py-20 md:py-32">
        <div className="container">
          <div className="text-center mb-16">
            <div className="flex items-center justify-center gap-2 mb-4">
              <div className="accent-line"></div>
              <span className="text-accent font-mono text-sm font-semibold">
                GALLERY
              </span>
              <div className="accent-line"></div>
            </div>
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              Before & After
            </h2>
            <p className="text-xl text-foreground/60 max-w-2xl mx-auto">
              See the transformation we bring to your spaces
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="space-y-4">
                <div className="bg-gradient-to-br from-accent/10 to-accent/5 rounded-lg h-48 border-2 border-accent/20 flex items-center justify-center">
                  <div className="text-center space-y-2">
                    <div className="text-4xl">📷</div>
                    <p className="text-sm text-foreground/60">Before image #{i}</p>
                  </div>
                </div>
                <div className="bg-gradient-to-br from-accent/10 to-accent/5 rounded-lg h-48 border-2 border-accent/20 flex items-center justify-center">
                  <div className="text-center space-y-2">
                    <div className="text-4xl">✨</div>
                    <p className="text-sm text-foreground/60">After image #{i}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32 bg-gradient-to-r from-accent/10 to-accent/5 border-y border-border">
        <div className="container text-center">
          <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-6">
            Questions? Contact Us Directly
          </h2>
          <p className="text-xl text-foreground/60 mb-8 max-w-2xl mx-auto">
            Reach out via WhatsApp or email for immediate assistance
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://wa.me/6143648613"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-accent text-accent-foreground px-8 py-4 rounded-lg hover:shadow-xl smooth-transition button-press font-semibold"
            >
              WhatsApp
            </a>
            <a
              href="mailto:solidspark45@gmail.com"
              className="border-2 border-accent text-accent px-8 py-4 rounded-lg hover:bg-accent/10 smooth-transition button-press font-semibold"
            >
              Email
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
