import { CheckCircle2, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

export default function Services() {
  const serviceCategories = [
    {
      title: "Прибирання квартир",
      description: "Комплексне прибирання вашої квартири з використанням екологічних засобів.",
      features: [
        "Генеральне прибирання",
        "Регулярне прибирання",
        "Прибирання після ремонту",
        "Чищення вікон",
        "Дезінфекція",
      ],
      price: "від $150",
    },
    {
      title: "Прибирання офісів",
      description: "Професійне прибирання офісних приміщень для чистоти та продуктивності.",
      features: [
        "Щоденне прибирання",
        "Чищення килимів",
        "Дезінфекція поверхонь",
        "Управління відходами",
        "Гнучкий графік",
      ],
      price: "від $200",
    },
    {
      title: "Генеральне прибирання",
      description: "Глибоке прибирання всіх куточків вашого простору.",
      features: [
        "Чищення стін",
        "Миття підлоги",
        "Чищення меблів",
        "Дезінсекція",
        "Видалення плісняви",
      ],
      price: "від $300",
    },
    {
      title: "Чищення килимів",
      description: "Спеціалізоване чищення килимів та меблів.",
      features: [
        "Глибоке чищення килимів",
        "Чищення меблів",
        "Видалення плям",
        "Дезодорація",
        "Швидке висушування",
      ],
      price: "від $100",
    },
    {
      title: "Дезінсекція",
      description: "Безпечна обробка від комах та шкідників.",
      features: [
        "Обробка від тарганів",
        "Обробка від мишей",
        "Обробка від комарів",
        "Екологічні засоби",
        "Гарантія результату",
      ],
      price: "від $250",
    },
    {
      title: "Чищення вікон",
      description: "Професійне чищення вікон та скла.",
      features: [
        "Чищення вікон",
        "Чищення скла",
        "Чищення дзеркал",
        "Чищення люстр",
        "Видалення плівок",
      ],
      price: "від $80",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-accent/10 to-accent/5 border-b border-border">
        <div className="container">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 mb-4">
              <div className="accent-line"></div>
              <span className="text-accent font-mono text-sm font-semibold">ПОСЛУГИ</span>
            </div>
            <h1 className="font-display text-5xl md:text-6xl font-bold text-foreground mb-4">
              Повний спектр послуг прибирання
            </h1>
            <p className="text-xl text-foreground/60">
              Ми пропонуємо професійні послуги прибирання для дому та офісу. Кожна послуга розроблена з урахуванням ваших потреб.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20 md:py-32">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {serviceCategories.map((service, i) => (
              <div
                key={i}
                className="group bg-card border border-border rounded-xl p-8 hover:shadow-xl smooth-transition hover:border-accent/50 flex flex-col"
              >
                <h3 className="font-display text-2xl font-bold text-foreground mb-2">
                  {service.title}
                </h3>
                <p className="text-foreground/60 mb-6 flex-grow">{service.description}</p>

                {/* Features */}
                <div className="space-y-3 mb-6 pb-6 border-b border-border">
                  {service.features.map((feature, j) => (
                    <div key={j} className="flex items-center gap-2">
                      <CheckCircle2 size={18} className="text-accent flex-shrink-0" />
                      <span className="text-foreground/70 text-sm">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* Price and CTA */}
                <div className="flex items-center justify-between">
                  <span className="font-display text-2xl font-bold text-accent">
                    {service.price}
                  </span>
                  <a
                    href="https://wa.me/1234567890"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-accent hover:text-accent/80 smooth-transition font-semibold flex items-center gap-2 group-hover:gap-3"
                  >
                    Замовити
                    <ArrowRight size={18} />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 md:py-32 bg-secondary/30 border-y border-border">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              Чому обирають нас
            </h2>
            <p className="text-xl text-foreground/60 max-w-2xl mx-auto">
              Ми забезпечуємо найвищу якість послуг з найменшими витратами
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                title: "Професіонали",
                description: "Досвідчена команда з 10+ років досвіду",
              },
              {
                title: "Екологічно",
                description: "Використовуємо безпечні для здоров'я засоби",
              },
              {
                title: "Надійно",
                description: "Гарантія якості на всі послуги",
              },
              {
                title: "Доступно",
                description: "Конкурентні ціни без прихованих витрат",
              },
            ].map((item, i) => (
              <div key={i} className="text-center">
                <div className="w-16 h-16 bg-accent/10 rounded-full flex items-center justify-center mx-auto mb-4">
                  <CheckCircle2 size={32} className="text-accent" />
                </div>
                <h3 className="font-display text-xl font-bold text-foreground mb-2">
                  {item.title}
                </h3>
                <p className="text-foreground/60">{item.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32">
        <div className="container text-center">
          <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-6">
            Готові замовити?
          </h2>
          <p className="text-xl text-foreground/60 mb-8 max-w-2xl mx-auto">
            Зв'яжіться з нами для безплатної консультації та кошторису
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://wa.me/1234567890"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-accent text-accent-foreground px-8 py-4 rounded-lg hover:shadow-xl smooth-transition button-press font-semibold"
            >
              WhatsApp
            </a>
            <a
              href="mailto:info@solidsparkclean.com"
              className="border-2 border-accent text-accent px-8 py-4 rounded-lg hover:bg-accent/10 smooth-transition button-press font-semibold"
            >
              Email
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
