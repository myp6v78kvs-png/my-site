import { ArrowRight, Calendar } from "lucide-react";
import { Link } from "wouter";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

export default function Blog() {
  const blogPosts = [
    {
      title: "Top 10 Cleaning Tips for Your Home",
      excerpt: "Learn the best practices for maintaining a clean and healthy home environment.",
      date: "May 20, 2024",
      category: "Tips",
      slug: "cleaning-tips",
    },
    {
      title: "Why Professional Cleaning Saves You Time",
      excerpt: "Discover how hiring professionals can free up your schedule and reduce stress.",
      date: "May 15, 2024",
      category: "Benefits",
      slug: "professional-cleaning-benefits",
    },
    {
      title: "Eco-Friendly Cleaning Products: What Works Best",
      excerpt: "Explore sustainable cleaning solutions that are safe for your family and the environment.",
      date: "May 10, 2024",
      category: "Eco-Friendly",
      slug: "eco-friendly-products",
    },
    {
      title: "Spring Cleaning Checklist for Every Room",
      excerpt: "A comprehensive guide to spring cleaning your entire home room by room.",
      date: "May 5, 2024",
      category: "Seasonal",
      slug: "spring-cleaning-checklist",
    },
    {
      title: "How Often Should You Deep Clean Your Office?",
      excerpt: "Guidelines for maintaining a clean and professional office environment.",
      date: "April 28, 2024",
      category: "Office",
      slug: "office-cleaning-frequency",
    },
    {
      title: "Removing Tough Stains: A Professional Guide",
      excerpt: "Expert techniques for tackling stubborn stains in your home.",
      date: "April 22, 2024",
      category: "Tips",
      slug: "stain-removal-guide",
    },
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-accent/10 to-accent/5 border-b border-border">
        <div className="container">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 mb-4">
              <div className="accent-line"></div>
              <span className="text-accent font-mono text-sm font-semibold">BLOG</span>
            </div>
            <h1 className="font-display text-5xl md:text-6xl font-bold text-foreground mb-4">
              Cleaning Tips & Insights
            </h1>
            <p className="text-xl text-foreground/60">
              Expert advice and industry insights to help you maintain a clean space
            </p>
          </div>
        </div>
      </section>

      {/* Blog Posts */}
      <section className="py-20 md:py-32">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {blogPosts.map((post, i) => (
              <div
                key={i}
                className="bg-card border border-border rounded-xl overflow-hidden hover:shadow-lg smooth-transition group"
              >
                <div className="bg-gradient-to-r from-accent/10 to-accent/5 h-40 flex items-center justify-center">
                  <div className="text-6xl">📝</div>
                </div>
                <div className="p-6">
                  <div className="flex items-center gap-2 mb-3">
                    <span className="text-xs font-semibold text-accent bg-accent/10 px-3 py-1 rounded-full">
                      {post.category}
                    </span>
                  </div>
                  <h3 className="font-display text-xl font-bold text-foreground mb-2 group-hover:text-accent smooth-transition">
                    {post.title}
                  </h3>
                  <p className="text-foreground/60 text-sm mb-4">{post.excerpt}</p>
                  <div className="flex items-center justify-between pt-4 border-t border-border">
                    <div className="flex items-center gap-2 text-xs text-foreground/50">
                      <Calendar size={14} />
                      {post.date}
                    </div>
                    <a
                      href="#"
                      className="text-accent hover:text-accent/80 smooth-transition font-semibold flex items-center gap-1 group-hover:gap-2"
                    >
                      Read
                      <ArrowRight size={16} />
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32 bg-gradient-to-r from-accent/10 to-accent/5 border-y border-border">
        <div className="container text-center">
          <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-6">
            Need Professional Cleaning?
          </h2>
          <p className="text-xl text-foreground/60 mb-8 max-w-2xl mx-auto">
            Contact us today for a free consultation
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://wa.me/6143648613"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-accent text-accent-foreground px-8 py-4 rounded-lg hover:shadow-xl smooth-transition button-press font-semibold"
            >
              WhatsApp
            </a>
            <a
              href="mailto:solidspark45@gmail.com"
              className="border-2 border-accent text-accent px-8 py-4 rounded-lg hover:bg-accent/10 smooth-transition button-press font-semibold"
            >
              Email
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
