import { Star } from "lucide-react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

export default function Reviews() {
  const allReviews = [
    // Chicago reviews
    ...Array(10).fill(null).map((_, i) => ({
      name: `Chicago Customer ${i + 1}`,
      rating: 5,
      text: "Excellent cleaning service! The team was professional, punctual, and thorough. Highly recommended!",
      city: "Chicago, IL",
      date: `${Math.floor(Math.random() * 30) + 1} days ago`,
    })),
    // Houston reviews
    ...Array(10).fill(null).map((_, i) => ({
      name: `Houston Customer ${i + 1}`,
      rating: 5,
      text: "Best cleaning service in Houston! My office looks brand new. Great value for money.",
      city: "Houston, TX",
      date: `${Math.floor(Math.random() * 30) + 1} days ago`,
    })),
    // Cleveland reviews
    ...Array(10).fill(null).map((_, i) => ({
      name: `Cleveland Customer ${i + 1}`,
      rating: 5,
      text: "Professional team, amazing results. They cleaned every corner perfectly. Will book again!",
      city: "Cleveland, OH",
      date: `${Math.floor(Math.random() * 30) + 1} days ago`,
    })),
  ];

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-accent/10 to-accent/5 border-b border-border">
        <div className="container">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 mb-4">
              <div className="accent-line"></div>
              <span className="text-accent font-mono text-sm font-semibold">REVIEWS</span>
            </div>
            <h1 className="font-display text-5xl md:text-6xl font-bold text-foreground mb-4">
              What Our Clients Say
            </h1>
            <p className="text-xl text-foreground/60">
              Join hundreds of satisfied customers across multiple cities
            </p>
          </div>
        </div>
      </section>

      {/* Reviews Grid */}
      <section className="py-20 md:py-32">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {allReviews.map((review, i) => (
              <div
                key={i}
                className="bg-card border border-border rounded-xl p-6 hover:shadow-lg smooth-transition"
              >
                <div className="flex items-center gap-1 mb-3">
                  {[...Array(review.rating)].map((_, j) => (
                    <Star key={j} size={16} className="fill-accent text-accent" />
                  ))}
                </div>
                <p className="text-foreground/70 mb-4 line-clamp-4 italic">
                  "{review.text}"
                </p>
                <div className="pt-4 border-t border-border">
                  <p className="font-semibold text-foreground text-sm">{review.name}</p>
                  <p className="text-xs text-foreground/60">{review.city}</p>
                  <p className="text-xs text-foreground/50 mt-1">{review.date}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 md:py-32 bg-gradient-to-r from-accent/10 to-accent/5 border-y border-border">
        <div className="container text-center">
          <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-6">
            Ready to Join Our Satisfied Clients?
          </h2>
          <p className="text-xl text-foreground/60 mb-8 max-w-2xl mx-auto">
            Contact us today for a free consultation
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="https://wa.me/6143648613"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-accent text-accent-foreground px-8 py-4 rounded-lg hover:shadow-xl smooth-transition button-press font-semibold"
            >
              WhatsApp
            </a>
            <a
              href="mailto:solidspark45@gmail.com"
              className="border-2 border-accent text-accent px-8 py-4 rounded-lg hover:bg-accent/10 smooth-transition button-press font-semibold"
            >
              Email
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
