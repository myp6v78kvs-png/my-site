import { MapPin, Phone, Mail, ArrowRight, Star } from "lucide-react";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";

export default function Columbus() {
  const neighborhoods = [
    "Downtown Columbus",
    "Short North",
    "German Village",
    "Clintonville",
    "Worthington",
    "New Albany",
    "Westerville",
    "Delaware",
  ];

  const reviews = Array(10).fill(null).map((_, i) => ({
    name: `Columbus Client ${i + 1}`,
    rating: 5,
    text: "Great cleaning service! Professional, reliable, and affordable. Highly satisfied!",
    area: "Columbus, OH",
  }));

  return (
    <div className="min-h-screen flex flex-col bg-background">
      <Navigation />

      {/* Hero Section */}
      <section className="py-16 md:py-24 bg-gradient-to-r from-accent/10 to-accent/5 border-b border-border">
        <div className="container">
          <div className="max-w-3xl">
            <div className="flex items-center gap-2 mb-4">
              <MapPin size={20} className="text-accent" />
              <span className="text-accent font-mono text-sm font-semibold">
                COLUMBUS, OH
              </span>
            </div>
            <h1 className="font-display text-5xl md:text-6xl font-bold text-foreground mb-4">
              Professional Cleaning in Columbus
            </h1>
            <p className="text-xl text-foreground/60">
              Expert cleaning services for homes and businesses throughout Columbus and surrounding areas.
            </p>
          </div>
        </div>
      </section>

      {/* Service Areas */}
      <section className="py-20 md:py-32">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              Service Areas in Columbus
            </h2>
            <p className="text-xl text-foreground/60">
              We serve all major neighborhoods
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
            {neighborhoods.map((neighborhood, i) => (
              <div
                key={i}
                className="bg-card border border-border rounded-lg p-4 text-center hover:border-accent/50 smooth-transition"
              >
                <p className="font-semibold text-foreground">{neighborhood}</p>
              </div>
            ))}
          </div>

          <div className="bg-gradient-to-r from-accent/10 to-accent/5 rounded-xl p-8 md:p-12 text-center">
            <h3 className="font-display text-2xl font-bold text-foreground mb-4">
              Your area not listed?
            </h3>
            <p className="text-foreground/60 mb-6">
              Contact us to check if we serve your location
            </p>
            <a
              href="https://wa.me/6143648613"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-accent text-accent-foreground px-8 py-3 rounded-lg hover:shadow-lg smooth-transition button-press font-semibold"
            >
              Ask
              <ArrowRight size={18} />
            </a>
          </div>
        </div>
      </section>

      {/* Reviews */}
      <section className="py-20 md:py-32 bg-secondary/30 border-y border-border">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
              Reviews from Columbus
            </h2>
            <p className="text-xl text-foreground/60">
              What our local clients say
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {reviews.map((review, i) => (
              <div key={i} className="bg-card border border-border rounded-xl p-8">
                <div className="flex items-center gap-1 mb-4">
                  {[...Array(review.rating)].map((_, j) => (
                    <Star key={j} size={18} className="fill-accent text-accent" />
                  ))}
                </div>
                <p className="text-foreground/70 mb-4 italic">"{review.text}"</p>
                <div className="pt-4 border-t border-border">
                  <p className="font-semibold text-foreground">{review.name}</p>
                  <p className="text-sm text-foreground/60">{review.area}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-20 md:py-32 bg-gradient-to-r from-accent/10 to-accent/5 border-y border-border">
        <div className="container">
          <div className="max-w-2xl mx-auto text-center">
            <h2 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-6">
              Contact Us
            </h2>
            <p className="text-xl text-foreground/60 mb-8">
              Ready to book cleaning services in Columbus?
            </p>

            <div className="space-y-4">
              <a
                href="https://wa.me/6143648613"
                target="_blank"
                rel="noopener noreferrer"
                className="block bg-accent text-accent-foreground px-8 py-4 rounded-lg hover:shadow-xl smooth-transition button-press font-semibold"
              >
                WhatsApp
              </a>
              <a
                href="tel:+16143648613"
                className="block border-2 border-accent text-accent px-8 py-4 rounded-lg hover:bg-accent/10 smooth-transition button-press font-semibold flex items-center justify-center gap-2"
              >
                <Phone size={20} />
                (614) 364-8613
              </a>
              <a
                href="mailto:solidspark45@gmail.com"
                className="block border-2 border-accent text-accent px-8 py-4 rounded-lg hover:bg-accent/10 smooth-transition button-press font-semibold flex items-center justify-center gap-2"
              >
                <Mail size={20} />
                solidspark45@gmail.com
              </a>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
