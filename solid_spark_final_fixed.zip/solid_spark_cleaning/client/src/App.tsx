import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import ChatWidget from "./components/ChatWidget";
import Home from "./pages/Home";
import Services from "./pages/Services";
import Reviews from "./pages/Reviews";
import Blog from "./pages/Blog";
import Gallery from "./pages/Gallery";
import Chicago from "./pages/Chicago";
import Houston from "./pages/Houston";
import Cleveland from "./pages/Cleveland";
import Columbus from "./pages/Columbus";
import Parma from "./pages/Parma";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/services"} component={Services} />
      <Route path={"/reviews"} component={Reviews} />
      <Route path={"/blog"} component={Blog} />
      <Route path={"/gallery"} component={Gallery} />
      <Route path={"/chicago"} component={Chicago} />
      <Route path={"/houston"} component={Houston} />
      <Route path={"/cleveland"} component={Cleveland} />
      <Route path={"/columbus"} component={Columbus} />
      <Route path={"/parma"} component={Parma} />
      <Route path={"/404"} component={NotFound} />
      {/* Final fallback route */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
          <ChatWidget />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
