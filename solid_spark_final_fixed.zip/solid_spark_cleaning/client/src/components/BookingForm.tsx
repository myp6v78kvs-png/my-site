import { useState } from "react";
import { Phone, Mail, Send } from "lucide-react";
import { toast } from "sonner";

export default function BookingForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    serviceType: "residential",
    date: "",
    time: "",
    address: "",
    message: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Validate form
      if (
        !formData.name ||
        !formData.email ||
        !formData.phone ||
        !formData.date ||
        !formData.address
      ) {
        toast.error("Please fill in all required fields");
        setIsSubmitting(false);
        return;
      }

      // Create message for WhatsApp and Email
      const bookingMessage = `
*New Booking Request from Solid Spark Cleaning Website*

Name: ${formData.name}
Email: ${formData.email}
Phone: ${formData.phone}
Service Type: ${formData.serviceType}
Preferred Date: ${formData.date}
Preferred Time: ${formData.time}
Address: ${formData.address}
Additional Message: ${formData.message || "None"}
      `.trim();

      // Send via WhatsApp
      const whatsappMessage = encodeURIComponent(bookingMessage);
      const whatsappUrl = `https://wa.me/6143648613?text=${whatsappMessage}`;

      // Send via Email
      const emailSubject = encodeURIComponent(
        "New Booking Request - Solid Spark Cleaning"
      );
      const emailBody = encodeURIComponent(bookingMessage);
      const emailUrl = `mailto:solidspark45@gmail.com?subject=${emailSubject}&body=${emailBody}`;

      // Show success message with options
      toast.success("Booking request prepared! Choose how to send it.", {
        duration: 5000,
      });

      // Open WhatsApp in new tab
      window.open(whatsappUrl, "_blank");

      // Reset form
      setFormData({
        name: "",
        email: "",
        phone: "",
        serviceType: "residential",
        date: "",
        time: "",
        address: "",
        message: "",
      });

      setIsSubmitting(false);
    } catch (error) {
      toast.error("Error processing booking request");
      setIsSubmitting(false);
    }
  };

  return (
    <div className="w-full max-w-2xl mx-auto">
      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Name and Email Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              Full Name *
            </label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              placeholder="John Doe"
              className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder:text-foreground/50 focus:outline-none focus:ring-2 focus:ring-accent smooth-transition"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              Email *
            </label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              placeholder="john@example.com"
              className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder:text-foreground/50 focus:outline-none focus:ring-2 focus:ring-accent smooth-transition"
              required
            />
          </div>
        </div>

        {/* Phone and Service Type Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              Phone Number *
            </label>
            <input
              type="tel"
              name="phone"
              value={formData.phone}
              onChange={handleChange}
              placeholder="(614) 123-4567"
              className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder:text-foreground/50 focus:outline-none focus:ring-2 focus:ring-accent smooth-transition"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              Service Type *
            </label>
            <select
              name="serviceType"
              value={formData.serviceType}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-accent smooth-transition"
            >
              <option value="residential">Residential Cleaning</option>
              <option value="office">Office Cleaning</option>
              <option value="deep">Deep Cleaning</option>
              <option value="carpet">Carpet Cleaning</option>
              <option value="window">Window Cleaning</option>
              <option value="other">Other Service</option>
            </select>
          </div>
        </div>

        {/* Date and Time Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              Preferred Date *
            </label>
            <input
              type="date"
              name="date"
              value={formData.date}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-accent smooth-transition"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              Preferred Time
            </label>
            <input
              type="time"
              name="time"
              value={formData.time}
              onChange={handleChange}
              className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground focus:outline-none focus:ring-2 focus:ring-accent smooth-transition"
            />
          </div>
        </div>

        {/* Address */}
        <div>
          <label className="block text-sm font-semibold text-foreground mb-2">
            Service Address *
          </label>
          <input
            type="text"
            name="address"
            value={formData.address}
            onChange={handleChange}
            placeholder="123 Main Street, City, State"
            className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder:text-foreground/50 focus:outline-none focus:ring-2 focus:ring-accent smooth-transition"
            required
          />
        </div>

        {/* Message */}
        <div>
          <label className="block text-sm font-semibold text-foreground mb-2">
            Additional Details
          </label>
          <textarea
            name="message"
            value={formData.message}
            onChange={handleChange}
            placeholder="Tell us more about your cleaning needs..."
            rows={4}
            className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder:text-foreground/50 focus:outline-none focus:ring-2 focus:ring-accent smooth-transition resize-none"
          />
        </div>

        {/* Submit Button */}
        <div className="flex flex-col sm:flex-row gap-3">
          <button
            type="submit"
            disabled={isSubmitting}
            className="flex-1 bg-accent text-accent-foreground px-8 py-4 rounded-lg hover:shadow-lg smooth-transition button-press font-semibold disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            <Send size={20} />
            {isSubmitting ? "Sending..." : "Send Booking Request"}
          </button>
          <a
            href="https://wa.me/6143648613"
            target="_blank"
            rel="noopener noreferrer"
            className="flex-1 border-2 border-accent text-accent px-8 py-4 rounded-lg hover:bg-accent/10 smooth-transition button-press font-semibold flex items-center justify-center gap-2"
          >
            <Phone size={20} />
            WhatsApp
          </a>
        </div>

        {/* Contact Info */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-border">
          <a
            href="tel:+16143648613"
            className="flex items-center gap-3 text-foreground hover:text-accent smooth-transition"
          >
            <Phone size={20} className="text-accent" />
            <div>
              <p className="text-sm text-foreground/60">Call us</p>
              <p className="font-semibold">(614) 364-8613</p>
            </div>
          </a>
          <a
            href="mailto:solidspark45@gmail.com"
            className="flex items-center gap-3 text-foreground hover:text-accent smooth-transition"
          >
            <Mail size={20} className="text-accent" />
            <div>
              <p className="text-sm text-foreground/60">Email us</p>
              <p className="font-semibold">solidspark45@gmail.com</p>
            </div>
          </a>
        </div>
      </form>
    </div>
  );
}
