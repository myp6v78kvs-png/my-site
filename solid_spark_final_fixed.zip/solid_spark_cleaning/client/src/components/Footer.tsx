import { Mail, Phone, MapPin, Facebook, Instagram, Linkedin } from "lucide-react";
import { Link } from "wouter";

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-foreground text-background mt-20">
      <div className="container py-16">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-accent rounded-lg flex items-center justify-center">
                <span className="text-foreground font-bold text-lg">S</span>
              </div>
              <span className="font-display font-bold text-lg">Solid Spark Cleaning</span>
            </div>
            <p className="text-background/70 text-sm">
              Professional cleaning services across multiple cities. Quality, reliability, results.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="font-display font-bold mb-4">Navigation</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/">
                  <a className="text-background/70 hover:text-accent smooth-transition text-sm">
                    Home
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/services">
                  <a className="text-background/70 hover:text-accent smooth-transition text-sm">
                    Services
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/reviews">
                  <a className="text-background/70 hover:text-accent smooth-transition text-sm">
                    Reviews
                  </a>
                </Link>
              </li>
            </ul>
          </div>

          {/* Service Areas */}
          <div>
            <h3 className="font-display font-bold mb-4">Service Areas</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/chicago">
                  <a className="text-background/70 hover:text-accent smooth-transition text-sm">
                    Chicago, IL
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/houston">
                  <a className="text-background/70 hover:text-accent smooth-transition text-sm">
                    Houston, TX
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/cleveland">
                  <a className="text-background/70 hover:text-accent smooth-transition text-sm">
                    Cleveland, OH
                  </a>
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="font-display font-bold mb-4">Contact</h3>
            <div className="space-y-3">
              <a
                href="tel:+16143648613"
                className="flex items-center gap-2 text-background/70 hover:text-accent smooth-transition text-sm"
              >
                <Phone size={16} />
                (614) 364-8613
              </a>
              <a
                href="mailto:solidspark45@gmail.com"
                className="flex items-center gap-2 text-background/70 hover:text-accent smooth-transition text-sm"
              >
                <Mail size={16} />
                solidspark45@gmail.com
              </a>
              <div className="flex items-center gap-2 text-background/70 text-sm">
                <MapPin size={16} />
                <span>Multiple Cities</span>
              </div>
            </div>
          </div>
        </div>

        {/* Divider */}
        <div className="h-px bg-background/20 mb-8"></div>

        {/* Bottom Section */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-background/60 text-sm">
            © {currentYear} Solid Spark Cleaning. All rights reserved.
          </p>

          {/* Social Links */}
          <div className="flex items-center gap-4">
            <a
              href="#"
              className="text-background/60 hover:text-accent smooth-transition"
              aria-label="Facebook"
            >
              <Facebook size={18} />
            </a>
            <a
              href="#"
              className="text-background/60 hover:text-accent smooth-transition"
              aria-label="Instagram"
            >
              <Instagram size={18} />
            </a>
            <a
              href="#"
              className="text-background/60 hover:text-accent smooth-transition"
              aria-label="LinkedIn"
            >
              <Linkedin size={18} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
